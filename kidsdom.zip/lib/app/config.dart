const String storyAgentUrl = String.fromEnvironment(
  'STORY_AGENT_URL',
  defaultValue: 'https://llm-generateitem-fjnopublia-uc.a.run.app',
);

// Renamed from `KidsTell.dart` to satisfy `file_names` (snake_case).
//
// The canonical application root (with DI/providers) lives in `app.dart`.
// Keeping this file as a re-export prevents accidental usage of an outdated
// app root and preserves backwards-compatible imports.
export 'app.dart';

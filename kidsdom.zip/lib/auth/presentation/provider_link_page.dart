import 'package:flutter/material.dart';

class ProviderLinkPage extends StatelessWidget {
  const ProviderLinkPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text('Provider linking (TODO)'),
          ),
        ),
      ),
    );
  }
}

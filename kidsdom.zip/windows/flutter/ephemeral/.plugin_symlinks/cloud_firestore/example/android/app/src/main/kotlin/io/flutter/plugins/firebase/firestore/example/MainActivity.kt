package io.flutter.plugins.firebase.firestore.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
